# Quick Short Maker — Android starter project (v2)

## Included in this version
- Pick a local video from your Android phone.
- Split it into sequential 30-second or 60-second MP4 clips.
- Optional 9:16 portrait crop for Shorts (center crop; it does not track faces).
- Optional caption text saved as a separate `.srt` subtitle file beside each MP4.
- Uses AndroidX Media3 Transformer for video export.

## Build the APK
1. Install Android Studio on a computer.
2. Extract this ZIP and open the `QuickShortMaker` folder in Android Studio.
3. Let Gradle sync. Use JDK 17.
4. Connect an Android phone with USB debugging enabled, or start an emulator.
5. Press **Run** to test. For an APK use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Output location
`Android/data/com.example.quickshortmaker/files/Movies/QuickShortMaker`

## Important limitations — read before publishing
- This version splits at fixed time intervals. It does NOT use AI to identify the most engaging or viral moments.
- Captions are user-entered and exported as `.srt` sidecar files. They are NOT automatically transcribed and are NOT burned into the MP4.
- The 9:16 option center-crops the frame. It does not automatically follow a speaker or keep faces in frame.
- Genuine AI highlight detection needs a video/audio analysis model or hosted AI service. Automatic speech-to-text needs an integrated speech recognition model/service. Those require implementation, testing, and potentially API credentials/costs; this project does not pretend those features are already active.
- Use only videos you own or have permission to edit. This app does not download videos from YouTube.

## App details
Display name: Quick Short Maker
Application ID: com.example.quickshortmaker
Version: 2.0 starter
