package com.example.quickshortmaker

import android.app.Activity
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.media3.common.Effects
import androidx.media3.common.MediaItem
import androidx.media3.effect.Presentation
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File
import java.util.Locale

class MainActivity : ComponentActivity() {
    private lateinit var status: TextView
    private lateinit var chooseButton: Button
    private lateinit var startButton: Button
    private lateinit var durationSpinner: Spinner
    private lateinit var captionInput: EditText
    private lateinit var portraitCheck: CheckBox

    private var selectedVideo: Uri? = null
    private var totalDurationMs = 0L
    private var segmentLengthMs = 60_000L
    private var nextStartMs = 0L
    private var currentEndMs = 0L
    private var clipNumber = 1
    private var outputFolder: File? = null
    private var transformer: Transformer? = null

    private val videoPicker = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let(::loadVideo)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 28, 24, 20)
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        val heading = TextView(this).apply {
            text = "Quick Short Maker"
            textSize = 27f
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 10)
        }
        val subtitle = TextView(this).apply {
            text = "Long video se short MP4 clips banayein"
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 16)
        }

        chooseButton = Button(this).apply {
            text = "Select Long Video"
            setOnClickListener { openVideoPicker() }
        }

        val durationLabel = TextView(this).apply {
            text = "Short duration:"
            textSize = 16f
            setPadding(0, 16, 0, 4)
        }
        durationSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                listOf("30 seconds", "60 seconds")
            )
            setSelection(1)
            onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: android.widget.AdapterView<*>?, view: android.view.View?,
                    position: Int, id: Long
                ) {
                    segmentLengthMs = if (position == 0) 30_000L else 60_000L
                }
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            }
        }

        portraitCheck = CheckBox(this).apply {
            text = "9:16 vertical crop for Shorts"
            isChecked = true
        }

        val captionLabel = TextView(this).apply {
            text = "Optional caption text (saved as .SRT subtitle file):"
            textSize = 14f
            setPadding(0, 8, 0, 4)
        }
        captionInput = EditText(this).apply {
            hint = "Yahan apne captions type/paste karein"
            minLines = 2
            maxLines = 4
            gravity = Gravity.TOP
        }

        startButton = Button(this).apply {
            text = "Create Shorts"
            isEnabled = false
            setOnClickListener { beginExport() }
        }
        status = TextView(this).apply {
            text = "Pehle video select karein."
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 8)
        }

        layout.addView(heading)
        layout.addView(subtitle)
        layout.addView(chooseButton)
        layout.addView(durationLabel)
        layout.addView(durationSpinner)
        layout.addView(portraitCheck)
        layout.addView(captionLabel)
        layout.addView(captionInput)
        layout.addView(startButton)
        layout.addView(status)
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    private fun openVideoPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
        }
        videoPicker.launch(intent)
    }

    private fun loadVideo(uri: Uri) {
        try {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(this, uri)
            totalDurationMs = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_DURATION
            )?.toLongOrNull() ?: 0L
            retriever.release()

            if (totalDurationMs <= 0L) {
                status.text = "Video duration read nahi ho saki."
                return
            }
            selectedVideo = uri
            startButton.isEnabled = true
            status.text = "Video selected: ${formatTime(totalDurationMs)}"
        } catch (e: Exception) {
            status.text = "Video open nahi hui: ${e.localizedMessage}"
        }
    }

    private fun beginExport() {
        val uri = selectedVideo ?: return
        val folder = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: filesDir
        outputFolder = File(folder, "QuickShortMaker").apply { mkdirs() }
        nextStartMs = 0L
        clipNumber = 1
        chooseButton.isEnabled = false
        startButton.isEnabled = false
        durationSpinner.isEnabled = false
        portraitCheck.isEnabled = false
        captionInput.isEnabled = false
        exportNext(uri)
    }

    private fun exportNext(uri: Uri) {
        if (nextStartMs >= totalDurationMs) {
            status.text = "Done! ${clipNumber - 1} clips saved:\n${outputFolder?.absolutePath}"
            chooseButton.isEnabled = true
            startButton.isEnabled = true
            durationSpinner.isEnabled = true
            portraitCheck.isEnabled = true
            captionInput.isEnabled = true
            return
        }

        currentEndMs = minOf(nextStartMs + segmentLengthMs, totalDurationMs)
        val mediaItem = MediaItem.Builder()
            .setUri(uri)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(nextStartMs)
                    .setEndPositionMs(currentEndMs)
                    .build()
            )
            .build()

        val effects = if (portraitCheck.isChecked) {
            Effects(
                emptyList(),
                listOf(Presentation.createForAspectRatio(
                    9f / 16f,
                    Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP
                ))
            )
        } else {
            Effects(emptyList(), emptyList())
        }

        val editedItem = EditedMediaItem.Builder(mediaItem)
            .setEffects(effects)
            .build()

        val output = File(outputFolder, "Short_${clipNumber}.mp4")
        status.text = "Creating Short $clipNumber...\n${formatTime(nextStartMs)} - ${formatTime(currentEndMs)}"

        transformer = Transformer.Builder(this)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(
                    composition: androidx.media3.transformer.Composition,
                    exportResult: ExportResult
                ) {
                    writeSubtitleFile(clipNumber, captionInput.text.toString())
                    nextStartMs = currentEndMs
                    clipNumber++
                    exportNext(uri)
                }

                override fun onError(
                    composition: androidx.media3.transformer.Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    status.text = "Export error: ${exportException.localizedMessage}"
                    enableControls()
                    output.delete()
                }
            })
            .build()

        try {
            transformer?.start(editedItem, output.absolutePath)
        } catch (e: Exception) {
            status.text = "Could not start export: ${e.localizedMessage}"
            enableControls()
        }
    }

    private fun writeSubtitleFile(number: Int, caption: String) {
        val clean = caption.trim()
        if (clean.isEmpty()) return
        val file = File(outputFolder, "Short_${number}.srt")
        // A single subtitle cue spanning this clip. This is a sidecar SRT,
        // not text burned into the MP4.
        val duration = currentEndMs - nextStartMs
        file.writeText(
            "1\n00:00:00,000 --> ${formatSrtTime(duration)}\n$clean\n",
            Charsets.UTF_8
        )
    }

    private fun formatSrtTime(ms: Long): String {
        val hours = ms / 3_600_000
        val minutes = (ms % 3_600_000) / 60_000
        val seconds = (ms % 60_000) / 1000
        val millis = ms % 1000
        return String.format(Locale.US, "%02d:%02d:%02d,%03d", hours, minutes, seconds, millis)
    }

    private fun enableControls() {
        chooseButton.isEnabled = true
        startButton.isEnabled = true
        durationSpinner.isEnabled = true
        portraitCheck.isEnabled = true
        captionInput.isEnabled = true
    }

    private fun formatTime(ms: Long): String {
        val seconds = ms / 1000
        return String.format(Locale.US, "%02d:%02d", seconds / 60, seconds % 60)
    }
}
